
/**
 * Write a description of class exercise4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;
public class exercise4
     {
      public static void main(String[]args)
      {
        JOptionPane.showMessageDialog(null,"For me to pass this module I have to work through the Smart Guide!!!",
        "Output Message",JOptionPane.WARNING_MESSAGE);
      }
     }
      
