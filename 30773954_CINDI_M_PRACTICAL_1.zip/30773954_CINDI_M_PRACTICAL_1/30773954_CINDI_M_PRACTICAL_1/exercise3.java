
/**
 * Write a description of class exercise3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;
public class exercise3
  {
    public static void main(String[]args)
    {
        JOptionPane.showMessageDialog(null,"Cindi Mosa");
    }
  }
    

