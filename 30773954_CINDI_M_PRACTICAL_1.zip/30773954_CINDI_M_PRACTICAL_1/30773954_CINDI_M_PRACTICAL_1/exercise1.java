
/**
 * Write a description of class exercise1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class exercise1
{
    public static void main(String[]args)
    {System.out.println("Hello");
     System.out.println("Cindi Mosa");
    }
}
     