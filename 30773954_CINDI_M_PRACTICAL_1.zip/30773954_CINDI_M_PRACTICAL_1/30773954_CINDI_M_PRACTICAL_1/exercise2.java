
/**
 * Write a description of class exercise2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class exercise2
{  
    public static void main(String[]args)
    {
        System.out.println(" +'''''+ \n[| o o |]\n |  ^  |\n | '-' |\n +-----+");
    }
}
