
/**
 * Write a description of class no1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Random;
public class no1
{
    public static void main(String[]args)
   {
    Random objGenerator=new Random();
    for (int iCount=0;iCount<10;iCount++)
    { int randomNumber=objGenerator.nextInt(10);
      System.out.println("Numbers are: " + randomNumber);
    }
   }
}

