
/**
 * Write a description of class no3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no3
 {
    public static void main(String[] args)
    {
      Scanner input = new Scanner(System.in);
      int sum = 0;
      char Option;
      do
      {
         System.out.println("Enter first number");
         int num1= input.nextInt();
         System.out.println("Enter second number");
         int num2= input.nextInt();
         sum =num1+num2;
         System.out.println("The sum of two numbers is: "+sum);
         System.out.println("Do you want to do another operation, Y/N");
         Option =input.next().charAt(0);
      }
      while(Option=='Y'||Option=='N');
   } 
 }
