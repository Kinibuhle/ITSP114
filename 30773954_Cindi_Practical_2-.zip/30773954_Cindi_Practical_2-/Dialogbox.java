
/**
 * Write a description of class exercise2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;
public class Dialogbox
{
    public static void main(String[]args)
    {
        JOptionPane.showMessageDialog(null,"Hallo ITSP 114 Student");
        String StudNum=JOptionPane.showInputDialog("Enter your StudNum");
        String StudName=JOptionPane.showInputDialog("Enter your StudName");
        String StudSurname=JOptionPane.showInputDialog("Enter your StudSurname");
        JOptionPane.showMessageDialog(null, "Student Number" + StudNum);
        JOptionPane.showMessageDialog(null,"Student Name" + StudName);
        JOptionPane.showMessageDialog(null,"Student Surname" + StudSurname);
    }
     
    }

