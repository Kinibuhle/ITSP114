
/**
 * Write a description of class StudentInformation here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class StudInfo
{
    public static void main(String args[])
    {
        System.out.println("Hallo ITSP 114 Student");
        Scanner input=new Scanner(System.in);
        System.out.println("Enter your student number");
        String StudNum=input.nextLine();
        System.out.println("Enter your name");
        String StudName=input.nextLine();
        System.out.println("Enter your surname");
        String StudSurname=input.nextLine();
        System.out.println("StudNum"+  StudNum);
        System.out.println("StudName"+  StudName);
        System.out.println("StudSurname"+  StudSurname);
        
    }
}
    
