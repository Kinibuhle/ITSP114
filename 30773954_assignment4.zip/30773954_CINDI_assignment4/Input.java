
/**
 * Write a description of class no5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Hallo 
{ 
    public static void main (String []args)
    {
       String Hallo_students=input.nextLine();
       String ITSP_114=input.nextLine();
       String Study_hard_for_semester_test=input.nextLine();
       String You_can_do_it=input.nextLine();
       System.out.println("Hallo_students + ITSP_114 +Study_hard_for_semester_test+You_can_do_it");
       
    }
}
