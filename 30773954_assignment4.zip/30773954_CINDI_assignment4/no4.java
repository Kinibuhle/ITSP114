
/**
 * Write a description of class no4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class no4
{ 
    public static void main (String[]args)
    { 
       String student_name="Tom Jefferson";
       int n= student_name.length();
       String nn=student_name.toLowerCase();
       char v=student_name.charAt(0);
       String van=student_name.substring(0,3);
       System.out.println(student_name.length());
       System.out.println(student_name.toLowerCase());
       System.out.println(student_name.charAt(0));
       System.out.println(student_name.substring(0,3));
    }
}     

    

