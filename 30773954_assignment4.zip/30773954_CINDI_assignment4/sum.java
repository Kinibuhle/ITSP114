
/**
 * Write a description of class sum here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class sum
{ public static void main (String[]args)
    {
     String item1="25.63";
     String item2="52";
     String together=item1+item2;
     double g1=Double.parseDouble(item1);
     int g2=Integer.parseInt(item2);
     double sum=g1+g2;
     System.out.println("The items together are" +sum);
    }
}