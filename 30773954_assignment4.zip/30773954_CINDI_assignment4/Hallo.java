
/**
 * Write a description of class no5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Hallo 
{ 
    public static void main (String []args)
    {
       Scanner input=new Scanner(System.in);
       Scanner Hallo_students=new Scanner(System.in);
       Scanner ITSP_114=new Scanner(System.in);
       Scanner Study_hard_for_semester_test=new Scanner(System.in);
       Scanner You_can_do_it=new Scanner(System.in);
       System.out.println("Hallo students  ITSP 114  Study hard for semester test  You can do it");
       
    }
}
