
/**
 * Write a description of class school_kiosk here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class school_kiosk
{
    public static void main (String[] args)
    {
    double change = 2.58;
    int cents1 = (int)(change*100);
    int cents2 = (int)(change*100);
    System.out.print("Change in cent is");
    System.out.println (cents1);
    System.out.print("Change in cent is");
    System.out.println (cents2);
   }
}    