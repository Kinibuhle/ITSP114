
/**
 * Write a description of class student_info here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class student_info
{ public static void main (String[]args)
   {
     String student_number="12345678";
     String student_name="Tom";
     String student_surname="Jefferson";
     String student_info=student_number+" "+student_name+" "+student_surname;
     System.out.print(student_info + ".");
    
    }
}
