
/**
 * Write a description of class no3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no3
{ public static void main(String[]args)
    {
        System.out.print("Which timetable would you like to practice:");
        int j,number;
        Scanner input=new Scanner(System.in);
        number=input.nextInt();
        System.out.println("\n");
        for(int i=0;i<=number;i++){
            System.out.println(number+"x"+i+"="+number*i);
        }
        }}
    
    
