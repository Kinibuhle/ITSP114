
/**
 * Write a description of class no2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no2
{
   public static void main(String[]args)
  {
   Scanner input=new Scanner(System.in);
   System.out.println("Enter Name and Surname: ");
   System.out.println("Enter mark: ");
   
   
  }}
