
/**
 * Write a description of class no1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
// Java program for the above approach
import java.util.Scanner;
public class no1
{
	public static void main(String[]args)
	{
	 Scanner sc = new Scanner(System.in);
        int number = 1 + (int)(10* Math.random());
	int K = 5;
        int i, userinput;
        System.out.println("You suppose to guess a number between 1-10: ");
	for (i = 0; i < K; i++) 
	{
	    System.out.println("Guess the number:");
	    userinput = sc.nextInt();
	    if (number == userinput)
	     {
		System.out.println("Thats a correct guess");
             }
	      else if( number > userinput&& i != K - 1)  
	        System.out.println("Try again"+userinput);
	 }
	 if (i == K)
	 {
            System.out.println("You've tried enough");
            System.out.println("The number was " + number);
         }
        }
    }
	       
	       
		

