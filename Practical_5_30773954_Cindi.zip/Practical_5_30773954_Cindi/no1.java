
/**
 * Write a description of class no1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;
public class no1
 { 
    public static void main (String[]args)
    {
      String input=JOptionPane.showInputDialog("Enter a number)");  
      int number=Integer.parseInt(input);
      if (number>=0)
         System.out.println(number +" positive ");
      else if (number<0)
         System.out.println(number +" negative ");
    }
  }
