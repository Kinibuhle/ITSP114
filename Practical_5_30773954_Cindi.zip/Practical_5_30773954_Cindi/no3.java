
/**
 * Write a description of class no3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;

public class no3
{
    public static void main (String[]args)
    {
      Scanner input=new Scanner(System.in);
      System.out.print("Enter name ");
      String WorkerName=input.nextLine();
      System.out.print("Enter hours worked ");
      double HoursWorked=input.nextDouble();
      double PayRate=0;
      System.out.print("Enter worker code ");
      char WorkerCode= input.next().charAt(0);
          if (WorkerCode == 'M')
          {
            PayRate=50.0*HoursWorked; 
          }
           else if (WorkerCode == 'W')
          {
            PayRate=30.0*HoursWorked;
          }
          else 
          {
          System.out.print("Invalid Code");
          return;
          }
      System.out.print("Salary Slip");
      System.out.print(" WorkerName " + WorkerName);
      System.out.print(" HoursWorked " + HoursWorked);
      System.out.print(" WorkerCode  " +WorkerCode);
      System.out.print(" PayRate "+ PayRate); 
    }
}
