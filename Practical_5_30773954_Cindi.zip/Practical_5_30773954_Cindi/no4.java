
/**
 * Write a description of class no4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no4
{
    public static void main (String[]args)
    {
      Scanner input=new Scanner(System.in);
      System.out.print("Enter your name ");
      String Name=input.nextLine();
      System.out.print("Enter mark ");
      double Mark1=input.nextDouble();
      System.out.print("Enter mark ");     
      double Mark2=input.nextDouble();
      System.out.print("Enter mark ");
      double Mark3=input.nextDouble();
      if(Mark1>=Mark2)
      System.out.print("Name " + Name + " Mark "+ Mark1 + " Highest mark");
      else if(Mark2>=Mark3)
      System.out.print("Name " + Name + " Mark "+ Mark2 + " Highest mark");
      else if(Mark3>=Mark1)
      System.out.print("Name " + Name + " Mark "+ Mark3 + " Highest mark");
    }
}