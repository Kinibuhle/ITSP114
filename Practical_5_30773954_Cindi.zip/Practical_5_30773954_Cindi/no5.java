
/**
 * Write a description of class no5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no5
{ 
    public static void main(String[]args)
    {
      int num;
      String temp;
      Scanner s=new Scanner(System.in);
      System.out.print("Enter number of names");
      num=s.nextInt();
      String names[]=new String(System.in);
      Scanner s1=new Scanner(System.in);
      System.out.print("Enter names");
      for (int i=0;i<num;i++)
       {
          names[i]=s1.nextline();
       }
      for (int i=0;i<num;i++)
        {
          for (int j=i +1;j<num;j++)
        {
        if (names[i].compareTo(names[j]> 0))
         {
           temp=names[i];
           names[i]=names[j];
           names[j]=temp;
         }
        }
       }
       System.out.print("Names in order ");
       for (int i=0;i<num-1;i++)
       {
           System.out.print(names[i]); 
       }
       System.out.print(names[num-1]);
    }
}
