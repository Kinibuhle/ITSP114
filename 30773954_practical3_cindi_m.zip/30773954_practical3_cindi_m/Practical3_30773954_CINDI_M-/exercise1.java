
/**
 * Write a description of class exercise1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class exercise1
{
    public static void main(String [] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter client's name");
        String ClientName=input.nextLine();
        System.out.println("Enter the cost of the car rented");
        double CarCost=input.nextDouble();
        System.out.println("Enter the number of days the car will be rented");
        double DaysRented=input.nextDouble();
        double VATprice = CarCost * 0.15;
        double VAT = 0.15;
        double TotalExclVat=CarCost *DaysRented;
        double TotalInclVAT = TotalExclVat +VATprice;
       System.out.println("client's name:" +ClientName);
       System.out.println("cost of the car rented:" +CarCost);
       System.out.println("number of days the car will be rented:"+DaysRented);
       System.out.println("total VAT: " +VAT);
       System.out.println("Total excluding VAT: " +TotalExclVat);
       System.out.println("Total including VAT: " +TotalInclVAT); 
       
    }
}

