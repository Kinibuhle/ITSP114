
/**
 * Write a description of class no4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no4
{ 
    public static void main(String[]args)
    {
        Scanner input=new Scanner(System.in);
        double HighestMark=0;
        System.out.print("Enter the name: ");
        String name=input.nextLine();
        System.out.print("Enter the Mark1: ");
        double Mark1=input.nextDouble();
        System.out.print("Enter the Mark2: ");
        double Mark2=input.nextDouble();
        System.out.print("Enter the Mark3: ");
        double Mark3=input.nextDouble();
        switch (1)
        {  
            case 1:
            HighestMark=Math.max(HighestMark,Mark1);
            case 2:
            HighestMark=Math.max(HighestMark,Mark2);
            case 3:
            HighestMark=Math.max(HighestMark,Mark3);
            break;
        }
        System.out.println("The highest mark is: "+ HighestMark);
    }
}
            
