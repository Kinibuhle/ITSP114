
/**
 * Write a description of class no3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no3
{
    public static void main(String[]args)
    {
        Scanner sc =new Scanner (System.in);
        System.out.println("Enter name: ");
        String Name=sc.nextLine();
        System.out.println("Enter hours worked: ");
        int HoursWorked=sc.nextInt();
        System.out.println("Enter code M or N: ");
        char WorkersCode=sc.next().charAt(0);
        double Rate=0;
        double Salary=0;
        switch (WorkersCode)
        {
          case 'M':
            Rate=50.00;
            Salary=HoursWorked*Rate;
          break;
          
          case 'W':
            Rate=30.00;
            Salary=HoursWorked*Rate;
          break;
        
          default:
            System.out.println("Invalid Code");
        }
        System.out.println("Salary Slip");
        System.out.println("Name of the worker: "+ Name);
        System.out.println("The hours worked by a worker: " + HoursWorked);
        System.out.println("The worker's code: "+ WorkersCode);
        System.out.println("Rate per hour is: R" + Rate);
        System.out.println("Worker's salary is: R"+ Salary);  
    }
}