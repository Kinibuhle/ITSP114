
/**
 * Write a description of class no2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no2
{  
    public static void main(String[]args)
    { 
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the name of the client: ");
        String ClientName=sc.nextLine();
        System.out.print("Enter the balance amount: ");
        double Balance=sc.nextDouble();
        switch (Double.compare(Balance,0.0))
        {
            case -1:
                System.out.println("Client's name is :" + ClientName);
                System.out.println("Balance is negative");
                break;
            case 0:
                System.out.println("Client's name is :" + ClientName);
                System.out.println("Balance is zero");
                break;
            default: 
                System.out.println("Balance is positive");
        }
    }
}
