
/**
 * Write a description of class no1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class no1
{ 
    public static void main (String[]args)
    {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter the number: ");
        int number= sc.nextInt();
        switch (number)
        {
            case 1:
                System.out.println("Positive");
                break;                
            case -1:
                System.out.println("Negative");
                break;
            default:
                System.out.println("Zero");
        }
    }
}
            
            
